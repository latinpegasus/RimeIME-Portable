rime with gits
==============

An input method for Windows powered by [Rime Input Method Engine](http://rime.im)
integrated into the open-source Google Input Tools framework.

http://github.com/lotem/rime-gits

Licencse
--------

GPLv3

Itemized:

  * Google Input Tools: Apache
  * brise: GPLv3
  * librime: BSD
  * opencc: Apache

Install
-------

Unpack (you did it already), run install.bat as Administrator.

Once successfully installed, enable Google Input Tools in system settings.

It takes time to deploy Rime data for first use.

A Note for Weasel users
-----------------------

This product is currently at alpha stage.
It can be installed along side existing Weasel installation.
User data for Weasel will not be imported to rime-gits.

While rime-gits fully implements librime, Weasel specific configuration and features
does not work for rime-gits for now, and may not be supported in the future.

Contribute
----------

Learn about project Rime at http://rime.im.

File issues in [Rime::Home](http://github.com/rime/home/issues).


Delivered by fredchen on 2015-10-10.
